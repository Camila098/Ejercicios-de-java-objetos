
/**
 Para el responsable se registra su DNI, nombre y apellido.
 **/
public class Responsable{
    private int dni;
    private String nombreYApellido;

    public Responsable(int dni, String nombreYApellido){
        setDni(dni);
        setNombre(nombreYApellido);
    }
    
    public Responsable(){
    }

    public int getDni(){
       return dni;
    }
    
    public String getNombre(){
       return nombreYApellido;
    }
    
    public void setDni(int dni){
       this.dni= dni;
    }
    
    public void setNombre(String nombreYApellido){
       this.nombreYApellido=nombreYApellido;
    }
}
