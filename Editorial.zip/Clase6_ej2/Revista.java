
/**
  Revista, que tiene asociado su nombre, un número de volumen y la cantidad de
 artículos en su interior.
 
 Los ejemplares deben poder imprimirse en un listado que se genera periódicamente, por ello
 se pide que las mismas definan un mensaje que les permita retornar un String con sus datos:
 
Para las revistas, su nombre y el número de volumen.

Por otro lado, cuando los ejemplares son publicados se agrega el año actual como año de
 publicación y, en particular para cada tipo de ejemplar:
 
Para las revistas, se agrega además el número de volumen (que se solicita mediante el
 método getNroVolumen() de la clase Generador que se descarga del entorno).
 **/
public class Revista extends Ejemplar{
    private String nombre;
    private int volumen;
    private int articulos;
    
    public Revista(String codigo, int anio, Responsable responsable, String nombre, int volumen, int articulos) {
        super(codigo,anio,responsable);
        this.nombre= nombre;
        setVolumen(volumen);
        this.articulos=articulos;
    }
    public Revista() {
    }
    
    public void setVolumen(int volumen){
        this.volumen = volumen;
    }
    
   public void publicar(){
       super.setAnio(2025);
       Generador g= new Generador();
       setVolumen(g.getNroVolumen());
    }
   
   public String toString(){
     String aux="Revista: "+"\n"+"Nombre: " + nombre+"\n"+"Numero de volumen: "+volumen;
     return aux;
    }
}
