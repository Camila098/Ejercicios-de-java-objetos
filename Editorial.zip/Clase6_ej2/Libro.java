
/**
 Libro, que también tiene asociado un título, la cantidad de capítulos del mismo y si es o
 no una edición de bolsillo.
 
 Los ejemplares deben poder imprimirse en un listado que se genera periódicamente, por ello
 se pide que las mismas definan un mensaje que les permita retornar un String con sus datos:
 
Para los libros, su código identificatorio, su título y el nombre del responsable.

Por otro lado, cuando los ejemplares son publicados se agrega el año actual como año de
 publicación y, en particular para cada tipo de ejemplar:
 
Para los libros, se concatena al final de su título si el mismo es o no una edición de bolsillo,
 por ejemplo, si el libro es “Programación en JAVA”, su título se modificará a “Programación
 en JAVA– DeBolsillo”
 **/
public class Libro extends Ejemplar{
    private String titulo;
    private int capitulos;
    private boolean esDeBolsillo;

    public Libro(String codigo, int anio, Responsable responsable,String titulo,int capitulos,boolean esDeBolsillo){
        super(codigo,anio,responsable);
        setTitulo(titulo);
        this.capitulos= capitulos;
        this.esDeBolsillo= esDeBolsillo;
    }
    public Libro(){}
    
    public String getTitulo(){
        return titulo;
    }
    
    public void setTitulo(String titulo){
       this.titulo= titulo;
    }
    
    public boolean getEsDeBolsillo(){
       return esDeBolsillo;
    }
     
    public void publicar(){
        super.setAnio(2025);
        if (esDeBolsillo) {
            setTitulo(titulo +" -De Bolsillo");
        }
    }
    
    public String toString(){
          String aux= "Libro: "+"\n";
          aux+= "código identificatorio: "+super.getCodigo()+"\n" +"Titulo: "+ titulo +"\n"+"Nombre del responsable: "+ super.getNombreResponsable();
          return aux;
    }
}
