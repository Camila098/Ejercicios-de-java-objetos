
/**
Cada Ejemplar posee un código identificatorio,
 cantidad de páginas, un resumen, año de publicación (si aún no fue publicado este valor es
 cero) y la información del responsable a cargo de la edición.
 **/
public abstract class Ejemplar
{
    private String codigo;
    private int anio;
    private Responsable responsable;

    
    public Ejemplar(String codigo, int anio, Responsable responsable){
        setCodigo(codigo);
        setAnio(0);   
        setResponsable(responsable);
    }
    
    public Ejemplar(){
    }

    public String getCodigo(){
       return codigo;
    }
    
    public int getAnio(){
       return anio;
    }
    
    public Responsable getResponsable(){
       return responsable;
    }
    
    public String getNombreResponsable(){
         return responsable.getNombre();
    }
    
    public void setCodigo(String codigo){
        this.codigo= codigo;
    }
    
    public void setAnio(int anio){
        this.anio= anio;
    }
    
    public void setResponsable(Responsable responsable){
        this.responsable= responsable;
    }
    
    public abstract String toString();
    public abstract void publicar();
}
