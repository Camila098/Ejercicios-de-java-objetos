
/**
 
 - Una editorial universitaria, necesita registrar la información correspondiente a los
 ejemplares que publicó y se publicarán. Cada Ejemplar posee un código identificatorio,
 cantidad de páginas, un resumen, año de publicación (si aún no fue publicado este valor es
 cero) y la información del responsable a cargo de la edición. Para el responsable se registra su
 DNI, nombre y apellido.
 Existen diferentes tipos de ejemplares:
Libro, que también tiene asociado un título, la cantidad de capítulos del mismo y si es o
 no una edición de bolsillo.
Revista, que tiene asociado su nombre, un número de volumen y la cantidad de
 artículos en su interior.
 
 Los ejemplares deben poder imprimirse en un listado que se genera periódicamente, por ello
 se pide que las mismas definan un mensaje que les permita retornar un String con sus datos:
 
Para los libros, su código identificatorio, su título y el nombre del responsable.

Para las revistas, su nombre y el número de volumen.

 Por otro lado, cuando los ejemplares son publicados se agrega el año actual como año de
 publicación y, en particular para cada tipo de ejemplar:
 
Para los libros, se concatena al final de su título si el mismo es o no una edición de bolsillo,
 por ejemplo, si el libro es “Programación en JAVA”, su título se modificará a “Programación
 en JAVA– DeBolsillo”
 
Para las revistas, se agrega además el número de volumen (que se solicita mediante el
 método getNroVolumen() de la clase Generador que se descarga del entorno).
 
 Se pide:
 a. Implementar la clase Ejemplar con sus respectivos atributos, constructores y
 métodos para acceder y modificar atributos.
 b. Implemente aquellas clases, métodos y objetos que considere necesarios para
 representar los diferentes tipos de ejemplares.
 c. Implementar la clase ProgramaEditorial, su método main y los métodos que
 considere necesarios para la lectura y almacenamiento de a lo sumo 1000
 ejemplares. Luego, haga la impresión de un listado de todos los ejemplares
 existentes.
 d. Escriba todos los métodos que considere necesarios para publicar los ejemplares de
 la editorial (considere los atributos del estado interno que se verán modificados).
 
 **/
import java.util.Scanner;
public class ProgPrincipal{
    public static void main (String[] args){
       int DIMF=1000,i,diml=0;
       Ejemplar[] vector= new Ejemplar[DIMF];
       
       for (i=0; i<DIMF; i++){
          vector[i]= leerEjemplar();
          diml++;
          if (vector[i].getCodigo().equals("0")){i=DIMF;} //deja de ingresar ejemplares si el codigo identificatorio es cero
        }
        
        System.out.println("\n"+"Lista de Ejemplares sin publicar: "+"\n");
        for (i=0; i<diml; i++){
          System.out.println(vector[i].toString()+"\n");
        }
        
        for (i=0; i<diml; i++){
          vector[i].publicar();
        }
        
        System.out.println("\n"+"Lista de Ejemplares publicados: "+"\n");
        for (i=0; i<diml; i++){
          System.out.println(vector[i].toString()+"\n");
        }
    }
    
    public static Ejemplar leerEjemplar(){
        Ejemplar aux=null;
        Scanner in = new Scanner(System.in);
          System.out.println("Ingrese los datos del ejemplar: ");
          System.out.println("Ingrese los datos del responsable: ");
          Responsable r= new Responsable(45789621,"Jose");
          System.out.println("Seleccione el numero del tipo de ejemplar: "+"\n"+"1:Libro"+"\n"+"2:Revista");
          int tipo= in.nextInt();
          if (tipo == 1){  aux= new Libro("45f5fd",0,r,"titulox",8,true);}
          if (tipo == 2){  aux= new Revista("45f5fd",0,r,"nombrex",45,11);}
        in.close();
        return aux;
    }
}
