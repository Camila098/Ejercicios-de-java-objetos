public class Hijo1 extends Padre{
    private int w;
    private double x;
    private boolean y;
    private String z;

    public Hijo1(int w,double x,boolean y,String z,AlgunColgadoHDP a){
        super(w,x,y,z,a);
        this.w=w;
        this.x=x;
        this.y=y;
        this.z=z;
    }
    
    public Hijo1(){    
    }

     public int getW(){
      return w;
    }
    
    public double getX(){
      return x;
    }
    
    public boolean getY(){
      return y;
    }
    
    public String getZ(){
      return z;
    }
    
    public void setW (int w){
        this.w=w;
    }
    
    public void setX (double x){
        this.x=x;
    }
    
    public void setY (boolean y){
        this.y=y;
    }
    
    public void setZ (String z){
        this.z=z;
    }
    
     public double calcularAlgo(){
        return (0.1);
    }
    
    public String toString(){
       return "Datos de : ";
    }
}
