public class Hijo2 extends Padre{
    private int w;
    private double x;
    private boolean y;
    private String z;
    private String[] vector;
    private int DIMF=20;
    private int diml;
    
    public Hijo2(int w,double x,boolean y,String z,AlgunColgadoHDP a){
        super(w,x,y,z,a);
        this.w=w;
        this.x=x;
        this.y=y;
        this.z=z;
        diml=0;
        vector= new String[DIMF];
        inicializarVector(vector);
    }
    
    public Hijo2(){    
    }
    
    private String[] inicializarVector(String[] v){
       for(int i=0; i<DIMF; i++){
          v[i]="";
        }
        return v;
    }
    
    public void agregarAlVector(String a){
        vector[diml]=a;
        diml++;
    }

     public int getW(){
      return w;
    }
    
    public double getX(){
      return x;
    }
    
    public boolean getY(){
      return y;
    }
    
    public String getZ(){
      return z;
    }
    
    public void setW (int w){
        this.w=w;
    }
    
    public void setX (double x){
        this.x=x;
    }
    
    public void setY (boolean y){
        this.y=y;
    }
    
    public void setZ (String z){
        this.z=z;
    }
    
     public double calcularAlgo(){
        return (0.1);
    }
    
    private String datosVector(){
        String aux= "\n Datos del vector: \n";
        for(int i=0; i<diml;i++ ){
           aux+= (i+1)+": "+vector[i]+".\n";
        }
       return aux;
    }
    
    public String toString(){
       return "Datos de : "+this.datosVector();
    }
}
