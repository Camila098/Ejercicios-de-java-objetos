public abstract class Padre{
    private int w;
    private double x;
    private boolean y;
    private String z;
    private AlgunColgadoHDP a;

    public Padre(int w,double x,boolean y,String z,AlgunColgadoHDP a){
        this.w=w;
        this.x=x;
        this.y=y;
        this.z=z;
        this.a=a;
    }
    
    public Padre(){
    }
    
    public int getW(){
      return w;
    }
    
    public double getX(){
      return x;
    }
    
    public boolean getY(){
      return y;
    }
    
    public String getZ(){
      return z;
    }
    
    public AlgunColgadoHDP getA(){
      return a;
    }
    
    public void setW (int w){
        this.w=w;
    }
    
    public void setX (double x){
        this.x=x;
    }
    
    public void setY (boolean y){
        this.y=y;
    }
    
    public void setZ (String z){
        this.z=z;
    }
    
    public void setA (AlgunColgadoHDP a){
        this.a=a;
    }
    
    abstract double calcularAlgo();
    
    public String toString(){
       return "Datos de : ";
    }

}
