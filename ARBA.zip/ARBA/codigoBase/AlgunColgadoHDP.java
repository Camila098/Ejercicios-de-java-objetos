public class AlgunColgadoHDP{
    private int dni;
    private String nomYApe;

    public AlgunColgadoHDP(int dni, String nomYApe){
        this.dni=dni;
        this.nomYApe=nomYApe;
    }

    public AlgunColgadoHDP(){
    }
    
    public int getDni(){
       return dni;
    }
    
    public String getNomYApe(){
       return nomYApe;
    }
    
    public void setDni(int dni){
        this.dni=dni;
    }
    
    public void setNomYApe(String nomYApe){
       this.nomYApe=nomYApe;
    }
    
    public String toString(){
       return "\nNombre: "+nomYApe+". DNI: "+dni;
    }

}
