import java.util.Scanner;
public class ProgramaPrincipal{
  public static void main(String[] args){
      final int DIMF= 20;
      Padre[] familia= new Padre[DIMF];
    
  
  Scanner in = new Scanner(System.in);
    for (int i=0; i<DIMF; i++){
        familia[i] = LeerDatos(in);
    }
  in.close();
  
  mostrarDatos(familia,DIMF);
  }
  
   public static Padre LeerDatos(Scanner in){
      int w; double x; boolean y; String z,h; Padre aux=null; AlgunColgadoHDP a;
      System.out.println("ingrese ? :");
      w=in.nextInt();
      System.out.println("ingrese ? :");
      x=in.nextDouble();
      System.out.println("ingrese ? :");
      y=in.nextBoolean();
      System.out.println("ingrese ? :");
      z=in.next();
      in.next();
      a=leerColgado(in);
      
      System.out.println("ingrese el hijo:");
      h=in.next();
      
      if (h.equals("hijo1")){
         Padre h1= new Hijo1(w,x,y,z,a);
         aux=h1;
        }
      else if (h.equals("hijo2")){
         Padre h2= new Hijo2(w,x,y,z,a);
         aux= h2;
        }
      else 
         System.out.println("el dato ingresado es incorrecto");
      
      return aux;
    }
  
  public static AlgunColgadoHDP leerColgado(Scanner in){
    int a; String b;
    
     System.out.println("ingrese ? :");
     a=in.nextInt();
     System.out.println("ingrese ? :");
     b=in.next();
    
    AlgunColgadoHDP p= new AlgunColgadoHDP(a,b);
    return p;
    }
    
  public static void mostrarDatos(Padre[] v,int DIMF){
    for(int i=0; i<DIMF; i++){
       System.out.println(v[i].toString());
       System.out.println("Cosa Calculada en el metodo abstracto: \n"+v[i].calcularAlgo());
    }
    
    }
  
}
