
public class Embarcacion extends Vehiculo{
    private int codigoREY;
    private String tipoEmbarcacion;
    private int eslora;
    private double peso;
    private double valor;

    public Embarcacion(int anio, double importe,Propietario propietario,int codigoREY, String tipoEmbarcacion,int eslora,double peso,double valor){
         super(anio,importe,propietario); 
         this.codigoREY= codigoREY;
         this.tipoEmbarcacion= tipoEmbarcacion;
         this.eslora= eslora;
         this.peso= peso;
         this.valor= valor;
    }
    
    
    public void setCodigoREY(int codigoREY){
        this.codigoREY= codigoREY;
    }
    
    public void setTipoEmbarcacion(String tipoEmbarcacion){
        this.tipoEmbarcacion= tipoEmbarcacion;
    }
    
    public void setEslora(int eslora){
        this.eslora= eslora;
    }
    
    public void setPeso(double peso){
       this.peso= peso;
    }
    
    public void setValor(double valor){
        this.valor= valor;
    }
    
    public double costosImpuestos(){
       double aux=0;
       if (valor < 6000){
         aux= (valor*4)/100;
        }
        else if((valor>= 6000)&&(valor<180000)){
          aux=(valor*2)/100;
        }
        else if(valor>=180000)
         aux=(valor*5)/100;
       return aux;
    }
    
    public String toString(){
      return super.toString()+"Datos de la Embarcacion: \n codigo REY: "+codigoREY+" tipo de embarcacion: "+tipoEmbarcacion+" eslora: "+eslora+" tonelaje: "+peso+" valor: "+valor;
    }
}