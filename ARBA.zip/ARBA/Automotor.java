public class Automotor extends Vehiculo{
    private double importeAdicional;
    private String patente;
    private String descripccion;

    public Automotor(int anio, double importe,Propietario propietario,double importeAdicional, String patente, String descripccion){
        super(anio,importe,propietario);
        this.importeAdicional= importeAdicional;
        this.patente= patente;
        this.descripccion= descripccion;
    }
    
    public void setImporteAdicional(double importeAdicional){
       this.importeAdicional= importeAdicional;
    }
    
    public void setPatente(String patente){
        this.patente= patente;
    }
    
    public void setDescripccion(String descripccion){
        this.descripccion= descripccion;
    }
    
    public double costosImpuestos(){
       return (super.getImporte() + importeAdicional);
    }
    
    public String toString(){
       return super.toString()+"Datos de automotor: \n"+"patente: "+patente+" importe adicional: "+importeAdicional+" descripccion: "+descripccion+"\n";
    }
}