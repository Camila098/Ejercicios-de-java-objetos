
public abstract class Vehiculo{
   private int anio;
   private double importe;
   private Propietario propietario;
    
   public Vehiculo(int anio, double importe,Propietario propietario){
       this.anio=anio;
       this.importe=importe;
       this.propietario=propietario;
    }
   
    public void setPropietario(Propietario propietario){
        this.propietario=propietario;
    }
    public void setAnio(int anio){
        this.anio=anio;
    }
    public void setImporte(double importe){
        this.importe=importe;
    }
    public int getAnio(){
        return anio;
    }
    public double getImporte(){
        return importe;
    }
    public Propietario getPropietario(){
        return propietario;
    } 
    
    public String setNombrePropietario(){
         return propietario.getNombre() +"  "+ propietario.getApellido();
    }
    
    public abstract double costosImpuestos();
    
    public String toString(){
       return "Datos del vehiculo: \n año de fabricacion: "+anio+" \n importe basico: "+importe+" \n Datos del Propietario: \n"+ propietario.toString();
    }
}
