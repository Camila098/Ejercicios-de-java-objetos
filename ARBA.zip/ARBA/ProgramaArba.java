import java.util.Scanner;
public class ProgramaArba{
    public static void main (String[] args){
      final int DIMF=2;
      Vehiculo[] vehiculos=new Vehiculo[DIMF];  
      
      Scanner in = new Scanner(System.in);
      leer(vehiculos,DIMF,in);
      in.close();
      
      mostrarCostos(vehiculos,DIMF);
    }
    
     public static Vehiculo[] leer(Vehiculo[] v,int DIMF ,Scanner in){
      String tipoVehiculo;
      int cod, eslora, anio ;
      double peso, valor, importeA, importeB;
      String tipoE, patente, descripccion;
      Propietario p;
         for(int i=0;i<DIMF;i++){
             
            System.out.println("ingrese los datos del vehiculo: ");
           System.out.println("Año de fabricacion: ");
            anio=in.nextInt();
           System.out.println("Importe de gestion basico: ");
            importeB=in.nextDouble();
            p=leerPropietario(in);  
           
           System.out.println("ingrese el tipo de vehiculo (embarcacion/automotor):");
           
           tipoVehiculo= in.next();
           if (tipoVehiculo.equals("embarcacion")){
               
               System.out.println("codigo de registro especial de Yates: ");
               cod=in.nextInt();
               System.out.println("tipo de embarcacion: ");
               tipoE=in.next();
               System.out.println("eslora: ");
               eslora=in.nextInt();
               System.out.println("tonelaje: ");
               peso=in.nextDouble();
               System.out.println("valor de la embarcacion: ");
               valor=in.nextDouble();
               Vehiculo e= new Embarcacion(anio,importeB,p,cod,tipoE,eslora,peso,valor);
               v[i]=e;
            }
            else if (tipoVehiculo.equals("automotor")){
               
               System.out.println("patente del automotor: ");
               patente=in.next();
               System.out.println("importe adicional segun el año de fabricacion: ");
               importeA=in.nextDouble();
               System.out.println("descripccion: ");
               descripccion=in.nextLine();
               in.next();
               
               Vehiculo a= new Automotor(anio,importeB,p,importeA,patente,descripccion);
               v[i]=a;
            }
            else
             System.out.println("opccion NO valida");
       }
       return v;
    }
    
    public static Propietario leerPropietario(Scanner in){
        
       String nom,ape; int cit;
       System.out.println("Ingrese la informacion del propietario: ");
           System.out.println("Nombre: ");
           nom= in.next();
           System.out.println("Apellido: ");
           ape= in.next();
           System.out.println("Clave de identificacion tributaria: ");
           cit= in.nextInt();
           Propietario p= new Propietario(nom,ape,cit);
           return p;
    }
    
    public static void mostrarCostos(Vehiculo[] v, int DIMF){
       for (int i=0; i< DIMF; i++){
          System.out.println(v[i].toString());
          System.out.println("El valor del impuesto a pagar por el propietario " +v[i].setNombrePropietario()+" es de "+ v[i].costosImpuestos()+ " pesos.");
        }
     
    }
    
  } 
