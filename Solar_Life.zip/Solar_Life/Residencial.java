public class Residencial extends Instalacion{
    private double superficie;
    private boolean tieneBaterias;

    public Residencial(int numeroDeContrato,double presupuestoBase,String f,boolean tieneCertificacion,String tipoDeEntorno,Cliente cliente,double superficie,boolean tieneBaterias){
        super(numeroDeContrato,presupuestoBase,f,tieneCertificacion,tipoDeEntorno,cliente);
        this.superficie=superficie;
        this.tieneBaterias=tieneBaterias;
    }
    
    public Residencial(){    
    }
    
    public double getSuperficie(){
      return superficie;
    }
    
    public boolean getTieneBaterias(){
      return tieneBaterias;
    }
    
    public void setSuperficie (double superficie){
        this.superficie=superficie;
    }
    
    public void setTieneBaterias (boolean tieneBaterias){
        this.tieneBaterias=tieneBaterias;
    }
    
    
    /** al presupuesto base se le suma un 10% si incluye sistema de baterías. 
    Si la superficie del techo es mayor a 50 m², se suma un plus del 5% por complejidad de montaje. **/
    
     public double calcularGanancias(){
         double aux= super.getPresupuestoBase() ;
         if (tieneBaterias){
              aux+=((super.getPresupuestoBase()*10)/100);
         }
         if(superficie > 50){
                 aux+=(super.getPresupuestoBase()*5)/100;
          }
        
        return aux;
    }
    
    public String toString(){
        String aux= super.toString()+"\n Datos de la residencia: ";
        aux+=  "\n Superficie del techo disponible (en m²): "+superficie+ "\n Sistema de almacenamiento por baterías: ";
        if (tieneBaterias)
           aux+= "SI";
        else 
           aux+= "NO";
        aux+="\n Ganancias obtenidas: "+calcularGanancias();
           
        return aux;
    }
}
