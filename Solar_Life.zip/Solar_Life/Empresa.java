
public class Empresa
{
    private int DIMF;
    private int diml;
    private Instalacion[] instalaciones;

    
    public Empresa(){
        DIMF=25;
        diml=0;
        instalaciones= new Instalacion[DIMF];
        inicializarInstalaciones(instalaciones);
    }
    
    private void inicializarInstalaciones( Instalacion[] instalaciones){
        for(int i=0; i<DIMF; i++){
            instalaciones[i]=null;
        }
       
    }
    
    public void agregarInstalacion (Instalacion i){
        instalaciones[diml]=i;
        diml++;
    }
    
    private double sumaDeMontosFinales(){
        double aux=0;
        for(int i=0; i<diml;i++){
           aux+= instalaciones[i].calcularGanancias();
        }
        
        return aux;
    }
    
    public String gananciaPromedio(){
        return "\n Ganancia promedio obtenida; "+(sumaDeMontosFinales()/diml);
    }
    
    public String toString(){
       String aux= "Datos de las instalaciones: \n";
        for(int i=0; i<diml;i++ ){
           aux+= instalaciones[i].toString();
        }
       return aux;
    }
    
}
