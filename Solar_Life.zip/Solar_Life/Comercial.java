public class Comercial extends Instalacion{
    private double potenciaMax;
    private boolean tienePrioridad;
    private String[] protocolos;
    private int DIMF=10;
    private int diml;
    
    public Comercial(int numeroDeContrato,double presupuestoBase,String f,boolean tieneCertificacion,String tipoDeEntorno,Cliente cliente,double potenciaMax,boolean tienePrioridad){
        super(numeroDeContrato,presupuestoBase,f,tieneCertificacion,tipoDeEntorno,cliente);
        this.potenciaMax=potenciaMax;
        this.tienePrioridad=tienePrioridad;
        diml=0;
        protocolos= new String[DIMF];
        inicializarVector(protocolos);
    }
    
    public Comercial(){    
    }
    
    private String[] inicializarVector(String[] v){
       for(int i=0; i<DIMF; i++){
          v[i]="";
        }
        return v;
    }
    
    public void agregarProtocolo(String a){
        protocolos[diml]=a;
        diml++;
    }
    
    public double getPotenciaMax(){
      return potenciaMax;
    }
    
    public boolean getTienePrioridad(){
      return tienePrioridad;
    }
    
    public void setPotenciaMax (double potenciaMax){
        this.potenciaMax=potenciaMax;
    }
    
    public void setTienePrioridad (boolean tienePrioridad){
        this.tienePrioridad=tienePrioridad;
    }
    
    private boolean esFeriado(){
        boolean aux= false; String fecha=super.getFecha();
        if((fecha.equals("01/01/2025"))||(fecha.equals("01/05/2025"))||(fecha.equals("09/07/2025"))||(fecha.equals("25/12/2025"))){
          aux=true;
        }
        
        return aux;
    }
    
    /**al presupuesto base se le suma un 20% si la 
     potencia es superior a 100 kW. Si la instalación es de "prioridad crítica" y se 
     realizó en días de alta demanda (feriados: 01/01/2025, 01/05/2025, 
     09/07/2025, 25/12/2025), se agrega un plus fijo de $45.000 **/
     
     public double calcularGanancias(){
        double aux= super.getPresupuestoBase() ;
         if (potenciaMax> 100){
              aux+=((super.getPresupuestoBase()*20)/100);
         }
         if(tienePrioridad){
             if (esFeriado()){
                   aux+= 45000;}
         }
            
        return aux;
    }
    
    private String datosVector(){
        String aux= "\n";
        for(int i=0; i<diml;i++ ){
           aux+= (i+1)+": "+protocolos[i]+".\n";
        }
       return aux;
    }
    
    public String toString(){
        String aux= super.toString()+ "\n Datos del comercio: ";
        aux+=  "\n Potencia máxima contratada (en kW): "+potenciaMax+ "\n Instalación de prioridad crítica : ";
        if (tienePrioridad)
           aux+= "SI";
        else 
           aux+= "NO";
        aux+= "\n Protocolos: "+this.datosVector();
        aux+="\n Ganancias obtenidas: "+calcularGanancias();

       return aux;
    }
}
