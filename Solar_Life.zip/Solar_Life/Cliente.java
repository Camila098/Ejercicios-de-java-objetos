public class Cliente{
    private int dni_ciut;
    private String nombre;
    private String metodoPago;

    public Cliente(int dni_ciut, String nombre,String metodoPago){
        this.dni_ciut=dni_ciut;
        this.nombre=nombre;
        this.metodoPago= metodoPago;
    }

    public Cliente(){
    }
    
    public int getDni_Cuit(){
       return dni_ciut;
    }
    
    public String getNombre(){
       return nombre;
    }
    
    public String getMetodoPago(){
       return metodoPago;
    }
    
    public void setDni_Cuit(int dni_ciut){
        this.dni_ciut=dni_ciut;
    }
    
    public void setNombre(String nombre){
       this.nombre=nombre;
    }
    
    public void setMetodoPago(String metodoPago){
      this.metodoPago= metodoPago;
    }
    
    public String toString(){
       return "\n Nombre: "+nombre+". DNI: "+dni_ciut+ " Metodo de Pago: "+metodoPago;
    }

}
