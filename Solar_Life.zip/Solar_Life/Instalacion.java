public abstract class Instalacion{
    private int numeroDeContrato;
    private double presupuestoBase;
    private String f;
    private boolean certificacionElectrica;
    private String tipoDeEntorno;
    private Cliente cliente;

    public Instalacion(int numeroDeContrato,double presupuestoBase,String f,boolean certificacionElectrica,String tipoDeEntorno,Cliente cliente){
        this.numeroDeContrato=numeroDeContrato;
        this.presupuestoBase=presupuestoBase;
        this.f=f;
        this.certificacionElectrica=certificacionElectrica;
        this.tipoDeEntorno=tipoDeEntorno;
        this.cliente=cliente;
    }
    
    public Instalacion(){
    }
    
    public int getNumeroDeContrato(){
      return numeroDeContrato;
    }
    
    public double getPresupuestoBase(){
      return presupuestoBase;
    }
    
    public String getFecha(){
       return f;
    }
    
    public boolean getCertificacionElectrica(){
      return certificacionElectrica;
    }
    
    public String getTipoDeEntorno(){
      return tipoDeEntorno;
    }
    
    public Cliente getCliente(){
      return cliente;
    }
    
    public void setNumeroDeContrato (int numeroDeContrato){
        this.numeroDeContrato=numeroDeContrato;
    }
    
    public void setPresupuestoBase (double presupuestoBase){
        this.presupuestoBase=presupuestoBase;
    }
    
    public void setFecha (String f){
        this.f=f;
    }
    
    public void setCertificacionElectrica (boolean certificacionElectrica){
        this.certificacionElectrica=certificacionElectrica;
    }
    
    public void setTipoDeEntorno (String tipoDeEntorno){
        this.tipoDeEntorno=tipoDeEntorno;
    }
    
    public void setCliente (Cliente cliente){
        this.cliente=cliente;
    }
    
    abstract double calcularGanancias();
    
    public String toString(){
        String aux= "\n";
        aux+= "\n Numero de contrato : "+numeroDeContrato+"\n Pesupuesto base: "+presupuestoBase+ "\n Fecha de instalacion: " +f+ "\n Certificacion electrica previa: ";
        if (certificacionElectrica)
            aux+= "SI";
        else 
            aux+= "NO";
        aux+= "\n Tipo de entorno: "+tipoDeEntorno+ "\n Datos del cliente: "+ cliente.toString();
        return aux;
    }

}
