import java.util.Scanner;
public class ProgramaPrincipal{
  public static void main(String[] args){
      Empresa Solar_Life = new Empresa();
    
      Cliente cli1= new Cliente(45178632,"jose Gonzalez","Transferencia");
      Cliente cli2= new Cliente(44777100,"lurdes lopazo","Efectivo");
      Cliente cli3= new Cliente(74418632,"checho diaz","cripto");
      Cliente cli4= new Cliente(45889614,"maria cabra","cripto");
      
      Instalacion r1=new Residencial(1,250000,"11/03/2025",true,"Urbano",cli1,20,true);
      Instalacion r2=new Residencial(2,500000,"8/11/2024",true,"Rural",cli2,70,false);
      
      Comercial c1=new Comercial(3,4000000,"01/01/2025",false,"Industrial",cli3,90,true);
      c1.agregarProtocolo("incendio");
      c1.agregarProtocolo("sobrecarga");
      Comercial c2=new Comercial(4,1200000,"31/02/2025",true,"Urbano",cli4,120,false);
      c2.agregarProtocolo("incendio externo");
      c2.agregarProtocolo("robo");
      c2.agregarProtocolo("transformador roto");
      
      Solar_Life.agregarInstalacion(r1);
      Solar_Life.agregarInstalacion(r2);
      Solar_Life.agregarInstalacion(c1);
      Solar_Life.agregarInstalacion(c2);
  
  
  System.out.println(Solar_Life.toString());
  System.out.println(Solar_Life.gananciaPromedio());
  }
  
}
