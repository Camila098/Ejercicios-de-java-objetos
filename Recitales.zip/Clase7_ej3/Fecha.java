
/**
  De cada “fecha” se conoce la ciudad y el día.
 **/
public class Fecha{
    private String ciudad;
    private int dia;

    public Fecha(){
    }

    
}
