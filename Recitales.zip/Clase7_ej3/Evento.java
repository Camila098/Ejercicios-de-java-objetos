
/**
  Un evento ocasional es un recital que además tiene el motivo (a beneficio o show de TV), el 
  nombre del contratante del recital y el día del evento. 
 **/
public class Evento extends Recital{
    private String motivo;
    private String nombreContratante;
    private String dia;
    
    /**El constructor de eventos ocasionales además recibe el 
    motivo, el nombre del contratante y día del evento.**/
    public Evento(String motivo, String nombreContratante, String dia){
        
    }
    public Evento(){
    }

    
}
