
/**
 3- Un productor musical desea administrar los recitales que organiza, que pueden ser: eventos 
ocasionales y giras. 
● De todo recital se conoce el nombre de la banda y la lista de temas que tocarán durante el 
recital.  
● Un evento ocasional es un recital que además tiene el motivo (a beneficio o show de TV), el 
nombre del contratante del recital y el día del evento. 
● Una gira es un recital que además tiene un nombre y las “fechas” donde se repetirá la 
actuación. De cada “fecha” se conoce la ciudad y el día. Además la gira guarda el número 
de la  fecha en la que se tocará próximamente (actual). 
a) Genere las clases necesarias. Implemente métodos getters/setters adecuados.  
b) Implemente los constructores. El constructor de recitales recibe el nombre de la banda y la 
cantidad de temas que tendrá el recital. El constructor de eventos ocasionales además recibe el 
motivo, el nombre del contratante y día del evento. El constructor de giras además recibe el 
nombre de la gira y la cantidad de fechas que tendrá. 
c) Implemente los métodos listados a continuación:  
i.  Cualquier recital debe saber responder a los mensajes: 
● agregarTema que recibe el nombre de un tema y lo agrega a la lista de temas.  
● Devolver el string para cada tema con la leyenda “y ahora tocaremos…” seguido por el 
nombre del tema. 
ii. La gira debe saber responder a los mensajes: 
● agregarFecha que recibe una “fecha” y la agrega adecuadamente. 
● Devuelve el string de manera distinta: Imprime la leyenda “Buenas noches …” seguido 
del nombre de la ciudad de la fecha “actual”. Luego debe imprimir el listado de temas 
como lo hace cualquier recital. Además debe establecer la siguiente fecha de la gira 
como la  nueva “actual”. 
iii. El evento ocasional debe saber devolver el string de manera distinta: 
● Si es un show de beneficencia devuelve la leyenda “Recuerden colaborar con…“ 
seguido del nombre del contratante.  
● Si es un show de TV devuelve “Saludos amigos televidentes”  
Independientemente del motivo del evento, luego se devuelve el listado de temas como lo 
hace cualquier recital. 
iv. Todo recital debe saber responder al mensaje calcularCosto teniendo en cuenta lo siguiente. 
Si es un evento ocasional devuelve 0 si es a beneficio y 50000 si es un show de TV. Las giras 
deben devolver 30000 por cada fecha de la misma. 
d) Realice un programa que instancie un evento ocasional y una gira, cargando la información 
necesaria. Luego, para ambos, imprima el costo y su información correspondiente.
 **/
public class ProgramaPrincipal
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class ProgramaPrincipal
     */
    public ProgramaPrincipal()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
