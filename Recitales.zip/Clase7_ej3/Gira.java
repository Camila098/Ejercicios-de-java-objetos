
/**
   Una gira es un recital que además tiene un nombre y las “fechas” donde se repetirá la 
   actuación. De cada “fecha” se conoce la ciudad y el día. Además la gira guarda el número 
   de la  fecha en la que se tocará próximamente (actual).
 **/
public class Gira extends Recital{
    private String nombreGira;
    private Fecha[] fechas;
    private int fechaActual;
    
    /**El constructor de giras además recibe el 
    nombre de la gira y la cantidad de fechas que tendrá.**/
    public Gira(String nombreGira, int cant){
        this.nombreGira=nombreGira;
        fechas= new Fecha[cant];
    }
    public Gira(){
    }

    
}
