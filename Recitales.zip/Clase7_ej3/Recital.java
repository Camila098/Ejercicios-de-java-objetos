
/**
   De todo recital se conoce el nombre de la banda y la lista de temas que tocarán durante el 
   recital.
 **/
public abstract class Recital
{
    private String nombre;
    private String[] temas;
    
    /** El constructor de recitales recibe el nombre de la banda y la 
    cantidad de temas que tendrá el recital.  **/
    public Recital(String nombre, int cant){
        this.nombre=nombre;
        temas= new String[cant];
    }
    public Recital(){
    }

    
}
