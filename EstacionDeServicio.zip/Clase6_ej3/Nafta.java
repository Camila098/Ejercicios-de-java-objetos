
/**
 Surtidor de Nafta, este surtidor no tiene límites de clientes, por lo cual sólo registra la
 cantidad de litros que tiene para proveer durante el día.
 
 se necesita calcular los impuestos que debe pagar y que se deducen de la siguiente
 manera:
  En el caso de la Nafta, se retiene el 2% por cada litro que tenga disponible para
 cargar el surtidor.
 **/
public class Nafta extends Surtidor{
    private double litros;

    public Nafta(double importe, int num, Playero playero,double litros){
        super(importe,num,playero);
        this.litros=litros;
    }
    public Nafta(){
    }
    
    public double calcularImpuesto(){
         double aux= (super.getImporte()*(0.02)) * (double)litros;
         return aux;
    }
    
    public String toString(){
        String aux= super.toString() + "Surtidor de Nafta: "+"\n"+"cantidad de litros que tiene para proveer durante el día: "+ litros+"\n";
        return aux;
    }
}
