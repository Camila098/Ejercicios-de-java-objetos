
/**
  Surtidor de Gasoil, debido a la escasez del combustible, este surtidor posee un límite
 diario de clientes a los que puede garantizarles la carga. Por lo que, tiene asociado el
 conjunto de patentes de aquellos vehículos que pudieron cargar gasoil (a lo sumo 20).
 
 se necesita calcular los impuestos que debe pagar y que se deducen de la siguiente
 manera:
  En el caso del Gasoil, se realiza el siguiente cálculo: si se les cargó gasoil hasta 5
 vehículos se le retiene el 5% del total facturado, si se les cargó a más de 5 y hasta 15
 vehículos se les retiene el 3% del importe facturado y a más de 15 vehículos se le
 retiene el 1,5% del importe total.
 **/
public class Gasoil extends Surtidor{
    private String[] patentes;
    private int DIMF=20;
    private int diml;
    
    public Gasoil(double importe, int num, Playero playero){
        super(importe,num,playero);
        this.patentes= new String[DIMF];
        this.diml=0;
    }
    public Gasoil(){}
    
    public void agregarPatente(String patente){
        if (diml <= DIMF){
           patentes[diml]= patente;
           if (diml < DIMF){ diml++;}
        }
    }
    
    public double calcularImpuesto(){
        double aux=0;
        if(diml <= 5){ aux= super.getImporte() *(0.05);}
        if(diml > 5 && diml <= 15){ aux= super.getImporte() *(0.03);}
        if(diml >15){ aux= super.getImporte() *(0.015);}
        return aux;
    }
    
    public String toString(){
        String aux; int i;
        aux= super.toString()+ "Surtidor de Gasoil: "+"\n";
        for (i=0; i<diml ; i++){
            aux+= "patente "+(i+1)+": "+patentes[i]+"\n";
        }
        return aux;
    }
}
