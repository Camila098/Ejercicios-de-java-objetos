
/**
 3- Una estación de servicio maneja las cargas de combustible de los vehículos que pasan por
 sus surtidores. De cada surtidor se registra: el número de surtidor, el importe total que facturó
 en el día, el DNI, nombre y apellido del playero que lo administró. 
Existen diferentes tipos de surtidores:
 ● Surtidor de Gasoil, debido a la escasez del combustible, este surtidor posee un límite
 diario de clientes a los que puede garantizarles la carga. Por lo que, tiene asociado el
 conjunto de patentes de aquellos vehículos que pudieron cargar gasoil (a lo sumo 20).
 ● Surtidor de Nafta, este surtidor no tiene límites de clientes, por lo cual sólo registra la
 cantidad de litros que tiene para proveer durante el día. 
Se pide: 
a. Implementar la clase Surtidor con sus respectivos atributos, constructores y
 métodos para acceder y modificar sus atributos. Además de todos los elementos
 necesarios para manejar los diferentes tipos de surtidores.
 b. La estación de servicio quiere saber cuánto dinero le queda de ganancia, para esto
 necesita calcular los impuestos que debe pagar y que se deducen de la siguiente
 manera:
 ● En el caso de la Nafta, se retiene el 2% por cada litro que tenga disponible para
 cargar el surtidor.
 ● En el caso del Gasoil, se realiza el siguiente cálculo: si se les cargó gasoil hasta 5
 vehículos se le retiene el 5% del total facturado, si se les cargó a más de 5 y hasta 15
 vehículos se les retiene el 3% del importe facturado y a más de 15 vehículos se le
 retiene el 1,5% del importe total.
 c. Implementar los métodos necesarios para imprimir toda la información de los
 surtidores.
 d. Implementar un programa principal que cargue dos surtidores de gasoil (uno con
 3 vehículos y uno con 8 vehículos) y un surtidor de nafta. Después de la carga,
 aplicar las retenciones y hacer la impresión de los datos utilizando lo
 implementado en el inciso c)
 **/
import java.util.Scanner;
public class ProgramaPrincipal{
   public static void main (String[] args){
      Playero p= new Playero(45879621,"Ricardo Rivera");
      Surtidor nafta= new Nafta(100000,0,p,56);
      Surtidor gasoil1= cargarVehiculos(3,p);
      Surtidor gasoil2= cargarVehiculos(8,p);
      
      //impresión de los datos
      System.out.println(nafta.toString());
      System.out.println(gasoil1.toString());
      System.out.println(gasoil2.toString());
    }
    
    public static Surtidor cargarVehiculos(int num, Playero p){
        int i;
        Gasoil gasoil= new Gasoil(100000,num,p);
        Scanner in= new Scanner(System.in);
        for (i=0; i<num; i++){
            System.out.println("ingrese la patente del vehiculo: ");
            gasoil.agregarPatente(in.next());
        }
        in.close();
        return gasoil;
    }
}
