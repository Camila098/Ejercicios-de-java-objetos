
/**
 el DNI, nombre y apellido del playero que lo administró.
 **/
public class Playero{
    private int dni;
    private String nombreYApellido;
    
    public Playero(int dni, String nombreYApellido){
        this.dni=dni;
        this.nombreYApellido= nombreYApellido;
    }
    public Playero(){
    }

    public String toString(){
        String aux="Nombre y apellido: "+ nombreYApellido+"\n"+"DNI: "+dni;
        return aux;
    }
}
