
/**
 De cada surtidor se registra: el número de surtidor, el importe total que facturó
 en el día, el DNI, nombre y apellido del playero que lo administró.
 **/
public abstract class Surtidor
{
    private double importe;
    private int num;
    private Playero playero;

    public Surtidor(double importe, int num, Playero playero){
         setImporte(importe);
         setNum(num);
         setPlayero(playero);
    }
    public Surtidor(){
    }

    public double getImporte(){
       return importe;
    }
    
    public int getNum(){
       return num;
    }
    
    public Playero getPlayero(){
       return playero;
    }
    
    public void setImporte(double importe){
        this.importe = importe;
    }
    
    public void setNum(int num){
        this.num = num;
    }
    
    public void setPlayero(Playero playero){
        this.playero = playero;
    }
    
    public abstract double calcularImpuesto();
    
    @Override
    public String toString(){
        String aux= "El surtidor n "+ num+ " facturo un total de "+importe+" pesos en el dia."+"\n";
        aux+= "Datos del playero: "+"\n"+playero.toString()+"\n";
        aux+= "Impuestos que debe pagar "+ calcularImpuesto()+" pesos."+"\n";
        return aux;
    }
    
}
